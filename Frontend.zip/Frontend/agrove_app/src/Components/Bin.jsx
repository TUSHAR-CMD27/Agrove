import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { FiRefreshCw, FiTrash2, FiArrowLeft, FiClock } from 'react-icons/fi';
import { useNavigate } from 'react-router-dom';
import './Bin.css';

const Bin = () => {
  const [deletedFields, setDeletedFields] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchBin();
  }, []);

  const fetchBin = async () => {
    try {
      const userInfo = JSON.parse(localStorage.getItem('userInfo'));
      const config = { headers: { Authorization: `Bearer ${userInfo.token}` } };
      const { data } = await axios.get('http://localhost:3000/api/fields/bin', config);
      setDeletedFields(data);
    } catch (err) {
      console.error("Error fetching bin", err);
    }
  };

  const handleRestore = async (id) => {
    try {
      const userInfo = JSON.parse(localStorage.getItem('userInfo'));
      const config = { headers: { Authorization: `Bearer ${userInfo.token}` } };
      await axios.patch(`http://localhost:3000/api/fields/${id}/restore`, {}, config);
      alert("Field restored successfully!");
      fetchBin();
    } catch (err) {
      alert("Restore failed");
    }
  };

  // Helper to calculate days remaining until permanent deletion
  const getDaysLeft = (expireAt) => {
    const remaining = new Date(expireAt) - new Date();
    const days = Math.ceil(remaining / (1000 * 60 * 60 * 24));
    return days > 0 ? days : 0;
  };

  return (
    <div className="bin-page-container">
      <div className="bin-header">
        <button className="back-dashboard-btn" onClick={() => navigate('/dashboard')}>
          <FiArrowLeft /> Back to Dashboard
        </button>
        
        <div className="bin-title-section">
          <h2><FiTrash2 className="title-icon" /> Recycle Bin</h2>
          <p>Fields stored here will be permanently deleted after 30 days.</p>
        </div>
      </div>

      <div className="bin-grid">
        {deletedFields.length === 0 ? (
          <div className="empty-bin-msg">
            <FiTrash2 size={48} />
            <p>Your recycle bin is empty.</p>
          </div>
        ) : (
          deletedFields.map(field => (
            <div key={field._id} className="bin-card">
              <div className="bin-card-info">
                <h3>{field.fieldName}</h3>
                <p className="delete-date">Deleted: {new Date(field.deletedAt).toLocaleDateString()}</p>
                {field.expireAt && (
                  <p className="expiry-countdown">
                    <FiClock /> {getDaysLeft(field.expireAt)} days remaining
                  </p>
                )}
              </div>
              <button className="restore-btn" onClick={() => handleRestore(field._id)}>
                <FiRefreshCw /> Restore Field
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Bin;