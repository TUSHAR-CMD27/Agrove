import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { FiSave, FiArrowLeft, FiPackage, FiType } from 'react-icons/fi';
import { FaRupeeSign } from "react-icons/fa";
import './AddActivity.css'; 

const EditPage = () => {
  const { type, id } = useParams(); 
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({});

  useEffect(() => {
    const fetchData = async () => {
      const userInfo = JSON.parse(localStorage.getItem('userInfo'));
      const config = { headers: { Authorization: `Bearer ${userInfo.token}` } };
      
      try {
        const endpoint = type === 'field' 
          ? `http://localhost:3000/api/fields/${id}` 
          : `http://localhost:3000/api/activities/${id}`;
        
        const res = await axios.get(endpoint, config);
        setFormData(res.data);
      } catch (err) {
        console.error("Error loading data", err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [id, type]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const userInfo = JSON.parse(localStorage.getItem('userInfo'));
    const config = { headers: { Authorization: `Bearer ${userInfo.token}` } };

    try {
      const endpoint = type === 'field'
        ? `http://localhost:3000/api/fields/${id}`
        : `http://localhost:3000/api/activities/${id}`;
      
      await axios.put(endpoint, formData, config);
      navigate(-1); 
    } catch (err) {
      alert("Update failed. Please try again.");
    }
  };

  if (loading) return <div className="loading-screen">Loading Data...</div>;

  return (
    <div className="add-activity-container">
      <div className="activity-header-section">
        <button onClick={() => navigate(-1)} className="back-btn-simple">
          <FiArrowLeft size={24} />
        </button>
        <h1>Edit {type === 'field' ? 'Field Plot' : 'Activity'}</h1>
      </div>

      <div className="form-card">
        <form onSubmit={handleSubmit}>
          {type === 'field' ? (
            <>
              <div className="form-group-act">
                <label>Field Name</label>
                <div className="input-with-icon">
                  <FiType />
                  <input type="text" name="fieldName" value={formData.fieldName || ''} onChange={handleChange} required />
                </div>
              </div>
              <div className="form-group-act">
                <label>Current Crop</label>
                <input type="text" name="currentCrop" value={formData.currentCrop || ''} onChange={handleChange} required />
              </div>
            </>
          ) : (
            <>
              <div className="form-group-act">
                <label>Product / Material</label>
                <div className="input-with-icon">
                  <FiPackage />
                  <input type="text" name="productName" value={formData.productName || ''} onChange={handleChange} />
                </div>
              </div>
              <div className="row-split">
                <div className="form-group-act">
                  <label>Quantity</label>
                  <input type="number" name="quantity" value={formData.quantity || ''} onChange={handleChange} />
                </div>
                <div className="form-group-act">
                  <label>Cost (₹)</label>
                  <div className="input-with-icon cost-input">
                    <FaRupeeSign />
                    <input type="number" name="cost" value={formData.cost || ''} onChange={handleChange} />
                  </div>
                </div>
              </div>
            </>
          )}
          <button type="submit" className="submit-act-btn">
            <FiSave /> Save Changes
          </button>
        </form>
      </div>
    </div>
  );
};

export default EditPage;